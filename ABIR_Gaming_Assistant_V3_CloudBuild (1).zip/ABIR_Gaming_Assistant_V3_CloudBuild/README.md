# ABIR Gaming Assistant V3 — Cloud Build Package

This package contains the ABIR Gaming Assistant Android project plus standard
Gradle wrapper configuration targeting Gradle 8.9.

If a cloud builder reports a missing `gradle-wrapper.jar`, use its built-in
Gradle/Android build option or let the service generate the wrapper first.
The source itself is a native Android Kotlin/Compose project.

Features in this prototype:
- ABIR Gaming Assistant branding
- Game Mode / performance profiles
- Sensitivity and HUD tool screens
- Headshot/Aim training entry points
- Manual floating-shortcut concept
- No auto-aim, auto-fire, target locking, game-memory modification, or
  anti-cheat bypass.

The cloud build service still needs network access to fetch Android/Gradle
dependencies.
