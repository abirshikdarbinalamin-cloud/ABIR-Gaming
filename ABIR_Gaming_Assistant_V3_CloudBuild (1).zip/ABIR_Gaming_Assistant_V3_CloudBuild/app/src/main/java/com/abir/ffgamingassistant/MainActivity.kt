package com.abir.ffgamingassistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    var performance by remember { mutableStateOf(true) }
    var profile by remember { mutableStateOf("Performance") }
    MaterialTheme(colorScheme = darkColorScheme()) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.padding(18.dp)) {
                Text("ABIR", style = MaterialTheme.typography.headlineLarge)
                Text("GAMING ASSISTANT", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(18.dp))
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("GAME MODE", style = MaterialTheme.typography.titleLarge)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Performance Mode")
                            Switch(performance, { performance = it })
                        }
                        Text("FPS Target  •  90     Touch  •  High     Temp  •  --")
                    }
                }
                Spacer(Modifier.height(14.dp))
                Text("PROFILE", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Balanced","Performance","Extreme").forEach {
                        FilterChip(profile == it, { profile = it }, label = { Text(it) })
                    }
                }
                Spacer(Modifier.height(14.dp))
                Text("FREE FIRE TOOLS", style = MaterialTheme.typography.titleMedium)
                val tools = listOf("Smart Sensitivity","HUD Studio","Headshot Trainer","Aim Lab","Floating Shortcut","Notifications")
                LazyVerticalGrid(columns = GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(tools) { Card { Text(it, Modifier.padding(16.dp)) } }
                }
                Spacer(Modifier.height(12.dp))
                Text("Manual tools only • No auto-aim • No auto-fire", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
